package com.company;

public interface Sofa {
    public void hasLegs();
    public void sitOn();
    public void hasSeats();
    public void lieOn();
}
