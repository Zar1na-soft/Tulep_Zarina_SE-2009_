package com.company;
public class DataBase {
    private static DataBase instance;
    private String str;
    private DataBase() {}
    public static DataBase getInstance() {
        if (DataBase.instance==null) {
            DataBase.instance=new DataBase();
        }
        return instance;
    }
    public void setStr(String str) {
        this.str = str;
    }
    public String getStr() {
        return str;
    }
}

