package com.company;

public class Test1 {
    public static void main(String[] args) {
        DataBase base = DataBase.getInstance();
        base.setStr("Hello");
        DataBase base1 = DataBase.getInstance();
        base1.setStr("Word");
    }
}

