package com.company;

public class Airplane implements Transport {
    @Override
    public void deliver() {
        System.out.println("Delivered by AIRPLANE");
    }
    }
