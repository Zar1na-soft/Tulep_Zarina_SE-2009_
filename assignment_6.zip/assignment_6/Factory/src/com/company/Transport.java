package com.company;

public interface Transport {
    public void deliver();
}

