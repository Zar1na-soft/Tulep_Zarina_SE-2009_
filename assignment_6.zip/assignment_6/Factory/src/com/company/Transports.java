package com.company;
public enum Transports {
    TRUCK, SHIP, AIRPLANE
}
